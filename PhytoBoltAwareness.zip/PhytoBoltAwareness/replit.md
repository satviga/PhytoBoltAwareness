# PhytoBolt: Ocean Awareness Website

## Overview

PhytoBolt is a data-rich, single-page awareness website focused on educating visitors about the critical relationship between phytoplankton and microplastics in our oceans. The project presents comprehensive environmental information through an interactive, presentation-like experience with extensive statistical data, detailed explanations of plastic reduction strategies, and animated live organism visualizations. Built as a modern web application with smooth animations and responsive design, it serves as a scientifically-grounded educational tool to raise awareness about marine environmental issues.

## Recent Changes (January 2025)

- Enhanced content with comprehensive statistical data and scientific facts
- Added detailed plastic reduction strategies with impact measurements  
- Integrated animated floating phytoplankton organisms throughout sections
- Improved microplastics visualization with contamination statistics
- Added live organism animations and better oceanic imagery
- Updated team information: SATVIGA (UX Designer & Research Lead), SANJAY (Lead Developer)

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application uses a React-based single-page application (SPA) architecture with modern component composition:

- **Framework**: React 18 with TypeScript for type safety and modern development patterns
- **Routing**: Wouter for lightweight client-side routing (though the main content is a single scrollable page)
- **Styling**: Tailwind CSS with custom oceanic theme colors and animations, configured with CSS variables for theming
- **UI Components**: Radix UI primitives with shadcn/ui component system for accessible, customizable components
- **Component Architecture**: Modular section-based components representing different "slides" of the presentation
- **Animation System**: CSS-based animations with Intersection Observer API for scroll-triggered animations

### State Management
- **Query Management**: TanStack Query (React Query) for server state management and caching
- **Local State**: React hooks (useState, useEffect) for component-level state management
- **Animation State**: Custom hook (`use-scroll-animation`) for managing scroll-based visibility states

### Build System
- **Bundler**: Vite for fast development and optimized production builds
- **TypeScript Configuration**: Strict TypeScript setup with path mapping for clean imports
- **Development Server**: Express.js server with Vite middleware for development, static serving for production

### Design System
The project implements a cohesive oceanic theme with:
- **Typography**: Montserrat for headings (bold, impactful), Poppins for body text (clean, readable)
- **Color Palette**: Deep ocean blues, teals, and electric yellow accents representing the "lightning bolt" brand element
- **Animation Framework**: Custom CSS animations for floating elements, glowing effects, bubbles, and scroll-triggered reveals
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts

### Content Structure
The application follows a storytelling narrative structure divided into thematic sections:
1. Hero section with split-screen imagery
2. Educational sections about phytoplankton and microplastics
3. Impact and consequence sections
4. Call-to-action and engagement sections
5. Team information and conclusion

### Backend Architecture
While primarily a static site, the project includes a minimal Express.js server structure:
- **Server Framework**: Express.js with TypeScript
- **Storage Interface**: Abstract storage interface with in-memory implementation (prepared for future database integration)
- **API Structure**: RESTful API patterns ready for future dynamic features
- **Session Management**: Configured for potential user sessions with PostgreSQL session store

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React, React DOM, React Router (Wouter)
- **TypeScript**: Full TypeScript support with strict configuration
- **Build Tools**: Vite, ESBuild for production bundling

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework with PostCSS processing
- **Radix UI**: Comprehensive set of accessible UI primitives
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Utility for component variant management

### Database and Data Management
- **Drizzle ORM**: Type-safe ORM with PostgreSQL dialect configuration
- **Neon Database**: Serverless PostgreSQL database connection (@neondatabase/serverless)
- **Zod**: Schema validation library integrated with Drizzle

### Development and Deployment
- **Replit Integration**: Specialized Vite plugins for Replit development environment
- **TypeScript**: Strict type checking and modern JavaScript features
- **React Query**: Server state synchronization and caching

### Media and Assets
- **Unsplash**: External image hosting for high-quality oceanic and environmental imagery
- **Google Fonts**: CDN-hosted web fonts (Montserrat, Poppins, Inter)

### Potential Production Dependencies
The project is configured to support:
- PostgreSQL database with session storage
- Form validation and submission
- Social media integration (prepared but not implemented)
- Analytics and tracking capabilities

The architecture prioritizes performance, accessibility, and maintainability while providing a foundation for potential future enhancements such as user interactions, content management, or dynamic data integration.