import { Zap, Mail, Twitter, Hash } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-ocean-deep py-12 border-t border-teal-dark" data-testid="footer">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <div className="mb-8">
          <div className="flex items-center justify-center mb-4">
            <Zap className="text-electric text-4xl mr-3 animate-lightning" size={64} />
            <h3 className="montserrat font-bold text-2xl">PhytoBolt</h3>
          </div>
          <p className="text-gray-400 mb-6">Saving the Ocean's Oxygen Factories</p>
          
          <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-8">
            <a 
              href="mailto:team@phytobolt.org" 
              className="text-teal-bright hover:text-electric transition-colors duration-300"
              data-testid="link-email"
            >
              <Mail className="inline mr-2" size={20} />team@phytobolt.org
            </a>
            <div className="text-teal-bright">
              <Twitter className="inline mr-2" size={20} />#SavePhytoplankton
            </div>
            <div className="text-teal-bright">
              <Hash className="inline mr-2" size={20} />HackTheOcean2025
            </div>
          </div>
        </div>
        
        <div className="border-t border-teal-dark pt-6">
          <p className="text-gray-500 text-sm">
            © 2025 PhytoBolt. All rights reserved. Built with 💚 for the ocean.
          </p>
        </div>
      </div>
    </footer>
  );
}
