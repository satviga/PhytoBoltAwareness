import { Microscope, Leaf, Globe } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function PhytoplanktonHeroes() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="heroes" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="heroes-section"
    >
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1583212292454-1fe6229603b7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-ocean-deep bg-opacity-60"></div>
      </div>
      
      {/* Animated floating phytoplankton organisms */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/6 w-3 h-3 bg-teal-bright rounded-full animate-float opacity-80" style={{animationDelay: '0s'}}></div>
        <div className="absolute top-1/3 right-1/4 w-2 h-2 bg-electric rounded-full animate-float opacity-60" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-1/3 left-1/3 w-4 h-4 bg-teal-bright rounded-full animate-float opacity-70" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-2/3 right-1/3 w-2 h-2 bg-electric rounded-full animate-float opacity-80" style={{animationDelay: '3s'}}></div>
        <div className="absolute bottom-1/4 right-1/6 w-3 h-3 bg-teal-bright rounded-full animate-float opacity-50" style={{animationDelay: '4s'}}></div>
        <div className="absolute top-1/2 left-1/5 w-1 h-1 bg-electric rounded-full animate-float opacity-90" style={{animationDelay: '2.5s'}}></div>
      </div>
      
      <div className={`relative z-10 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8">
          Meet the Heroes: <span className="text-teal-bright text-glow">Phytoplankton</span>
        </h2>
        <p className="text-2xl md:text-3xl mb-4 text-electric">
          Tiny ocean plants = Earth's oxygen factories
        </p>
        <div className="bg-teal-dark bg-opacity-30 rounded-xl p-4 mb-8">
          <p className="text-sm text-electric font-semibold">Amazing Fact: 1 trillion phytoplankton can fit in a single glass of seawater!</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          <div className="bg-teal-dark bg-opacity-50 rounded-xl p-6 animate-glow">
            <Microscope className="text-electric text-4xl mb-4 mx-auto" size={64} />
            <h3 className="montserrat font-semibold text-xl mb-2">Microscopic Size</h3>
            <p className="text-sm mb-3">Invisible to the naked eye but vital to all life</p>
            <div className="text-xs text-gray-400 space-y-1">
              <p>• 0.2-2 micrometers in size</p>
              <p>• 5 billion in 1 liter of water</p>
              <p>• Smaller than bacteria</p>
            </div>
          </div>
          <div className="bg-teal-dark bg-opacity-50 rounded-xl p-6 animate-glow" style={{animationDelay: '0.3s'}}>
            <Leaf className="text-electric text-4xl mb-4 mx-auto" size={64} />
            <h3 className="montserrat font-semibold text-xl mb-2">Oxygen Producers</h3>
            <p className="text-sm mb-3">Generate 50-85% of the oxygen we breathe</p>
            <div className="text-xs text-gray-400 space-y-1">
              <p>• 330 billion tons O₂ yearly</p>
              <p>• More than all forests combined</p>
              <p>• Via photosynthesis process</p>
            </div>
          </div>
          <div className="bg-teal-dark bg-opacity-50 rounded-xl p-6 animate-glow" style={{animationDelay: '0.6s'}}>
            <Globe className="text-electric text-4xl mb-4 mx-auto" size={64} />
            <h3 className="montserrat font-semibold text-xl mb-2">Global Impact</h3>
            <p className="text-sm mb-3">Foundation of marine food chains worldwide</p>
            <div className="text-xs text-gray-400 space-y-1">
              <p>• Feed 99% of marine life</p>
              <p>• $2.5 trillion ocean economy</p>
              <p>• Support 3 billion people</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
