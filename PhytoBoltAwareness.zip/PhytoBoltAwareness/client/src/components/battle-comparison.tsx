import { Heart, Skull } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function BattleComparison() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="battle" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="battle-section"
    >
      <div className={`w-full max-w-7xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl text-center mb-12 text-glow">
          The Silent Battle
        </h2>
        <p className="text-xl md:text-2xl text-center mb-12 text-teal-bright">
          Phytoplankton vs. microplastics: A war we can't see, but we must fight
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Healthy Phytoplankton Side */}
          <div className="relative rounded-2xl overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1583212292454-1fe6229603b7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Healthy glowing phytoplankton" 
              className="w-full h-80 object-cover"
            />
            <div className="absolute inset-0 bg-teal-dark bg-opacity-30 flex items-center justify-center">
              <div className="text-center">
                <Heart className="text-electric text-6xl mb-4 animate-glow mx-auto" size={96} />
                <h3 className="montserrat font-bold text-2xl text-glow">Healthy Heroes</h3>
                <p className="text-lg mt-2">Thriving & producing oxygen</p>
              </div>
            </div>
          </div>
          
          {/* Polluted Side */}
          <div className="relative rounded-2xl overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1621451537084-482c73073a0f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Microplastics contaminating ocean water" 
              className="w-full h-80 object-cover"
            />
            <div className="absolute inset-0 bg-red-900 bg-opacity-60 flex items-center justify-center">
              <div className="text-center">
                <Skull className="text-red-400 text-6xl mb-4 mx-auto" size={96} />
                <h3 className="montserrat font-bold text-2xl text-red-400">Microplastic-Choked Waters</h3>
                <p className="text-lg mt-2">Phytoplankton suffocating and dying</p>
                <div className="text-xs text-red-300 mt-3 space-y-1">
                  <p>• 51 trillion microplastic pieces in oceans</p>
                  <p>• 40% phytoplankton decline since 1950</p>
                  <p>• Toxic chemicals leaching into cells</p>
                </div>
              </div>
            </div>
            
            {/* Animated microplastic particles */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <div className="absolute top-1/4 left-1/6 w-1 h-1 bg-red-400 opacity-80 animate-float" style={{animationDelay: '0s'}}></div>
              <div className="absolute top-1/3 right-1/4 w-2 h-1 bg-red-300 opacity-60 animate-float" style={{animationDelay: '0.5s'}}></div>
              <div className="absolute bottom-1/3 left-1/3 w-1 h-2 bg-red-400 opacity-70 animate-float" style={{animationDelay: '1s'}}></div>
              <div className="absolute top-2/3 right-1/3 w-1 h-1 bg-red-300 opacity-80 animate-float" style={{animationDelay: '1.5s'}}></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
