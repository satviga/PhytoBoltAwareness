import { Ban, Hand, Megaphone } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function ActionSteps() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="action-steps" 
      className="min-h-screen flex items-center justify-center relative ocean-gradient"
      data-testid="action-steps-section"
    >
      <div className={`text-center max-w-5xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-12 text-glow">
          What Can We Do?
        </h2>
        <p className="text-xl md:text-2xl mb-12 text-teal-bright">
          Simple steps matter
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-teal-dark bg-opacity-40 rounded-2xl p-8 hover:bg-opacity-60 transition-all duration-300 animate-glow">
            <Ban className="text-electric text-5xl mb-6 mx-auto" size={80} />
            <h3 className="montserrat font-bold text-2xl mb-4">Reduce Plastics</h3>
            <p className="text-lg mb-4">Say NO to single-use plastics</p>
            <div className="bg-ocean-blue bg-opacity-30 rounded-xl p-4 mb-4">
              <p className="text-sm text-electric font-semibold">Impact: 8 million tons of plastic enter oceans yearly</p>
            </div>
            <ul className="text-sm text-gray-300 space-y-3">
              <li>• <span className="text-electric">Reusable bags:</span> Save 1000+ plastic bags/year</li>
              <li>• <span className="text-electric">Metal straws:</span> Prevent 36,500 plastic straws annually</li>
              <li>• <span className="text-electric">Glass containers:</span> Reduce microplastic contamination</li>
              <li>• <span className="text-electric">Refill stations:</span> Avoid 1,500 plastic bottles/year</li>
              <li>• <span className="text-electric">Bamboo products:</span> Biodegradable alternatives</li>
            </ul>
          </div>
          
          <div className="bg-teal-dark bg-opacity-40 rounded-2xl p-8 hover:bg-opacity-60 transition-all duration-300 animate-glow" style={{animationDelay: '0.3s'}}>
            <Hand className="text-electric text-5xl mb-6 mx-auto" size={80} />
            <h3 className="montserrat font-bold text-2xl mb-4">Support Cleanups</h3>
            <p className="text-lg mb-4">Join ocean restoration efforts</p>
            <div className="bg-ocean-blue bg-opacity-30 rounded-xl p-4 mb-4">
              <p className="text-sm text-electric font-semibold">Success: 4.4M volunteers removed 350M lbs of trash</p>
            </div>
            <ul className="text-sm text-gray-300 space-y-3">
              <li>• <span className="text-electric">Beach cleanups:</span> Remove 2-3 lbs plastic per person</li>
              <li>• <span className="text-electric">Ocean Conservancy:</span> Global cleanup initiatives</li>
              <li>• <span className="text-electric">Local groups:</span> Weekly coastal restoration</li>
              <li>• <span className="text-electric">Donate funds:</span> $1 removes 1 lb of ocean plastic</li>
              <li>• <span className="text-electric">Adopt coastlines:</span> Long-term protection programs</li>
            </ul>
          </div>
          
          <div className="bg-teal-dark bg-opacity-40 rounded-2xl p-8 hover:bg-opacity-60 transition-all duration-300 animate-glow" style={{animationDelay: '0.6s'}}>
            <Megaphone className="text-electric text-5xl mb-6 mx-auto" size={80} />
            <h3 className="montserrat font-bold text-2xl mb-4">Spread Awareness</h3>
            <p className="text-lg mb-4">Share the message</p>
            <div className="bg-ocean-blue bg-opacity-30 rounded-xl p-4 mb-4">
              <p className="text-sm text-electric font-semibold">Power: 1 share reaches 150+ people on average</p>
            </div>
            <ul className="text-sm text-gray-300 space-y-3">
              <li>• <span className="text-electric">Educational posts:</span> Share phytoplankton facts</li>
              <li>• <span className="text-electric">Photo evidence:</span> Document plastic pollution</li>
              <li>• <span className="text-electric">Challenge friends:</span> 30-day plastic reduction</li>
              <li>• <span className="text-electric">School talks:</span> Present to science classes</li>
              <li>• <span className="text-electric">Hashtag campaigns:</span> #SavePhytoplankton</li>
            </ul>
          </div>
        </div>
        
        {/* Human hand holding hope image */}
        <div className="mt-12">
          <img 
            src="https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
            alt="Hands cupping glowing bioluminescent organisms" 
            className="w-80 h-60 rounded-2xl mx-auto shadow-2xl animate-glow object-cover"
          />
        </div>
      </div>
    </section>
  );
}
