import { Heart, Fish, Thermometer } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function WhyItMatters() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="crisis" 
      className="min-h-screen flex items-center justify-center relative ocean-gradient"
      data-testid="crisis-section"
    >
      <div className={`text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-12 text-glow">
          Why It Matters to Us
        </h2>
        
        <div className="space-y-8">
          <div className="flex items-center justify-start bg-teal-dark bg-opacity-30 rounded-xl p-6 animate-glow">
            <div className="bg-electric rounded-full p-4 mr-6 flex-shrink-0">
              <Heart className="text-ocean-deep text-2xl" size={32} />
            </div>
            <div className="text-left">
              <h3 className="montserrat font-semibold text-xl mb-2">50-85% of Earth's oxygen</h3>
              <p className="text-gray-300">comes from phytoplankton in our oceans</p>
              <p className="text-sm text-electric mt-1">That's more oxygen than all forests combined!</p>
            </div>
          </div>
          
          <div className="flex items-center justify-start bg-teal-dark bg-opacity-30 rounded-xl p-6 animate-glow" style={{animationDelay: '0.3s'}}>
            <div className="bg-electric rounded-full p-4 mr-6 flex-shrink-0">
              <Fish className="text-ocean-deep text-2xl" size={32} />
            </div>
            <div className="text-left">
              <h3 className="montserrat font-semibold text-xl mb-2">99% of marine food chains</h3>
              <p className="text-gray-300">depend entirely on these microscopic organisms</p>
              <p className="text-sm text-electric mt-1">3 billion people rely on ocean food sources</p>
            </div>
          </div>
          
          <div className="flex items-center justify-start bg-teal-dark bg-opacity-30 rounded-xl p-6 animate-glow" style={{animationDelay: '0.6s'}}>
            <div className="bg-electric rounded-full p-4 mr-6 flex-shrink-0">
              <Thermometer className="text-ocean-deep text-2xl" size={32} />
            </div>
            <div className="text-left">
              <h3 className="montserrat font-semibold text-xl mb-2">40 billion tons of CO2</h3>
              <p className="text-gray-300">absorbed annually by ocean phytoplankton</p>
              <p className="text-sm text-electric mt-1">Equal to removing 8.5 billion cars from roads</p>
            </div>
          </div>
        </div>
        
        {/* Animated Earth Visual */}
        <div className="mt-12 relative">
          <img 
            src="https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400" 
            alt="Earth from space showing blue planet" 
            className="w-60 h-60 rounded-full mx-auto animate-glow object-cover"
          />
        </div>
      </div>
    </section>
  );
}
