import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function BigQuestionSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="big-question" 
      className="min-h-screen flex items-center justify-center relative ocean-gradient"
      data-testid="big-question-section"
    >
      <div className={`text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8 text-glow">
          Did you know?
        </h2>
        <p className="text-2xl md:text-4xl mb-12 text-teal-bright">
          Half of every breath you take comes from the ocean
        </p>
        
        {/* Animated Oxygen Bubbles */}
        <div className="relative h-40 overflow-hidden">
          <div className="absolute bottom-0 left-1/4 w-4 h-4 bg-electric rounded-full animate-bubble opacity-70"></div>
          <div className="absolute bottom-0 left-1/2 w-6 h-6 bg-teal-bright rounded-full animate-bubble opacity-80" style={{animationDelay: '0.5s'}}></div>
          <div className="absolute bottom-0 right-1/4 w-3 h-3 bg-electric rounded-full animate-bubble opacity-60" style={{animationDelay: '1s'}}></div>
          <div className="absolute bottom-0 left-1/3 w-5 h-5 bg-teal-bright rounded-full animate-bubble opacity-75" style={{animationDelay: '1.5s'}}></div>
          <div className="absolute bottom-0 right-1/3 w-2 h-2 bg-electric rounded-full animate-bubble opacity-90" style={{animationDelay: '2s'}}></div>
        </div>
      </div>
    </section>
  );
}
