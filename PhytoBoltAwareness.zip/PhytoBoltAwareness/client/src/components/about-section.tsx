import { User, GraduationCap, Trophy } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function AboutSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="about" 
      className="min-h-screen flex items-center justify-center relative ocean-gradient"
      data-testid="about-section"
    >
      <div className={`text-center max-w-5xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8 text-glow">
          The Team Behind PhytoBolt
        </h2>
        <p className="text-xl md:text-2xl mb-12 text-teal-bright">
          We built PhytoBolt to turn awareness into action
        </p>
        
        <div className="bg-teal-dark bg-opacity-40 rounded-3xl p-8 mb-12 backdrop-blur-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8 max-w-2xl mx-auto">
            {/* Team Member Cards */}
            <div className="bg-ocean-blue bg-opacity-50 rounded-xl p-6">
              <div className="w-16 h-16 bg-electric rounded-full mx-auto mb-4 flex items-center justify-center">
                <User className="text-ocean-deep text-2xl" size={32} />
              </div>
              <h3 className="montserrat font-semibold text-lg">SATVIGA</h3>
              <p className="text-sm text-gray-300">UX Designer & Research Lead</p>
            </div>
            
            <div className="bg-ocean-blue bg-opacity-50 rounded-xl p-6">
              <div className="w-16 h-16 bg-electric rounded-full mx-auto mb-4 flex items-center justify-center">
                <User className="text-ocean-deep text-2xl" size={32} />
              </div>
              <h3 className="montserrat font-semibold text-lg">SANJAY</h3>
              <p className="text-sm text-gray-300">Lead Developer</p>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-lg mb-4">
              <GraduationCap className="inline text-electric mr-2" size={24} />
              Ocean University - Computer Science & Environmental Studies
            </p>
            <p className="text-lg mb-6">
              <Trophy className="inline text-electric mr-2" size={24} />
              HackTheOcean 2025 Participants
            </p>
            <blockquote className="text-xl md:text-2xl italic text-electric border-l-4 border-electric pl-6 max-w-3xl mx-auto">
              "We built PhytoBolt to turn awareness into action—because the ocean can't wait."
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}
