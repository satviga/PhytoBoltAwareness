import { Zap, Microscope, Award, HandHeart } from "lucide-react";
import { useScrollAnimation, scrollToSection } from "@/hooks/use-scroll-animation";

export default function ConclusionSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="conclusion" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="conclusion-section"
    >
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-ocean-deep bg-opacity-60"></div>
      </div>
      
      <div className={`relative z-10 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <div className="animate-lightning mb-8">
          <Zap className="text-electric text-8xl mx-auto" size={128} />
        </div>
        
        <blockquote className="text-3xl md:text-5xl montserrat font-bold mb-12 leading-tight">
          <span className="text-glow">"The ocean gives us life</span>
          <br />
          <span className="text-electric">now it's our turn to protect it."</span>
        </blockquote>
        
        <div className="flex items-center justify-center space-x-4 mb-12">
          <div className="animate-glow">
            <img 
              src="https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200" 
              alt="Earth glowing blue from space" 
              className="w-32 h-32 rounded-full object-cover"
            />
          </div>
          <div className="text-electric text-6xl animate-lightning">
            <Zap size={96} />
          </div>
          <div className="text-center">
            <h3 className="montserrat font-bold text-2xl text-electric">PhytoBolt</h3>
            <p className="text-sm text-gray-300">Saving Oxygen Factories</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button 
            onClick={() => scrollToSection('heroes')}
            className="bg-teal-dark bg-opacity-50 hover:bg-opacity-70 rounded-xl p-6 transition-all duration-300 animate-glow"
            data-testid="button-learn-more"
          >
            <Microscope className="text-electric text-3xl mb-3 mx-auto" size={48} />
            <h4 className="montserrat font-semibold">Learn More</h4>
          </button>
          
          <button 
            onClick={() => scrollToSection('challenge')}
            className="bg-teal-dark bg-opacity-50 hover:bg-opacity-70 rounded-xl p-6 transition-all duration-300 animate-glow" 
            style={{animationDelay: '0.3s'}}
            data-testid="button-take-pledge"
          >
            <Award className="text-electric text-3xl mb-3 mx-auto" size={48} />
            <h4 className="montserrat font-semibold">Take Pledge</h4>
          </button>
          
          <button 
            onClick={() => scrollToSection('action-steps')}
            className="bg-teal-dark bg-opacity-50 hover:bg-opacity-70 rounded-xl p-6 transition-all duration-300 animate-glow" 
            style={{animationDelay: '0.6s'}}
            data-testid="button-take-action"
          >
            <HandHeart className="text-electric text-3xl mb-3 mx-auto" size={48} />
            <h4 className="montserrat font-semibold">Take Action</h4>
          </button>
        </div>
      </div>
    </section>
  );
}
