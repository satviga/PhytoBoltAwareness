import { Zap, ArrowDown } from "lucide-react";
import { useScrollAnimation, scrollToSection } from "@/hooks/use-scroll-animation";

export default function HeroSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      className="relative min-h-screen flex items-center justify-center hero-split"
      data-testid="hero-section"
    >
      {/* Healthy Ocean Background (Left) */}
      <div 
        className="absolute inset-0 w-1/2 left-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-teal-dark bg-opacity-30"></div>
      </div>
      
      {/* Polluted Ocean Background (Right) */}
      <div 
        className="absolute inset-0 w-1/2 right-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1621451537084-482c73073a0f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-red-900 bg-opacity-50"></div>
      </div>
      
      {/* Hero Content */}
      <div className={`relative z-20 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <div className="animate-lightning mb-6">
          <Zap className="text-electric text-8xl mx-auto" size={128} />
        </div>
        <h1 className="montserrat font-bold text-5xl md:text-7xl mb-6 text-glow">
          PhytoBolt: Zapping Microplastics to Save the Ocean's Oxygen
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-gray-200">
          The invisible crisis threatening half of Earth's oxygen
        </p>
        <button 
          onClick={() => scrollToSection('crisis')}
          className="bg-electric hover:bg-electric-dark text-ocean-deep montserrat font-bold px-8 py-4 rounded-full text-lg transition-all duration-300 animate-glow"
          data-testid="button-learn-truth"
        >
          Learn the Truth <ArrowDown className="inline ml-2" size={20} />
        </button>
      </div>

      {/* Floating Particles Animation */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-electric rounded-full animate-float"></div>
        <div className="absolute top-1/2 right-1/3 w-3 h-3 bg-teal-bright rounded-full animate-float" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-1/4 left-1/3 w-1 h-1 bg-electric rounded-full animate-float" style={{animationDelay: '2s'}}></div>
      </div>
    </section>
  );
}
