import { Sun, Skull } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function MicroplasticsVillain() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="villain" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="villain-section"
    >
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1605600659908-0ef719419d41?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-red-900 bg-opacity-60"></div>
      </div>
      
      <div className={`relative z-10 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8">
          Enter the Villain: <span className="text-red-400">Microplastics</span>
        </h2>
        <p className="text-xl md:text-2xl mb-8 text-gray-200">
          Invisible plastic particles block sunlight, poison phytoplankton, and spread everywhere
        </p>
        <div className="bg-red-900 bg-opacity-30 rounded-xl p-4 mb-8 border border-red-500">
          <p className="text-sm text-red-300 font-semibold">Shocking Reality: 51 trillion microplastic pieces contaminate our oceans - 500x more than stars in our galaxy!</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="bg-red-900 bg-opacity-50 rounded-xl p-6 border border-red-500">
            <Sun className="text-red-400 text-4xl mb-4 mx-auto" size={64} />
            <h3 className="montserrat font-semibold text-xl mb-4">Blocks Sunlight</h3>
            <p className="mb-3">Prevents photosynthesis in phytoplankton</p>
            <div className="text-xs text-red-300 space-y-1">
              <p>• 30% light reduction in contaminated areas</p>
              <p>• Photosynthesis drops by 50%</p>
              <p>• Creates ocean "dead zones"</p>
            </div>
          </div>
          <div className="bg-red-900 bg-opacity-50 rounded-xl p-6 border border-red-500">
            <Skull className="text-red-400 text-4xl mb-4 mx-auto" size={64} />
            <h3 className="montserrat font-semibold text-xl mb-4">Toxic Poison</h3>
            <p className="mb-3">Releases harmful chemicals into ocean cells</p>
            <div className="text-xs text-red-300 space-y-1">
              <p>• 232 toxic chemicals in microplastics</p>
              <p>• BPA levels 1000x higher than seawater</p>
              <p>• Disrupts cellular reproduction</p>
            </div>
          </div>
        </div>
        
        {/* Additional impact statistics */}
        <div className="bg-black bg-opacity-50 rounded-2xl p-6 border border-red-600">
          <h4 className="montserrat font-bold text-lg mb-4 text-red-300">The Numbers Don't Lie</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="text-center">
              <p className="text-2xl font-bold text-red-400">8M tons</p>
              <p className="text-gray-300">plastic enter oceans yearly</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-red-400">40% decline</p>
              <p className="text-gray-300">phytoplankton since 1950</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-red-400">5mm size</p>
              <p className="text-gray-300">microplastics ingested by plankton</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
