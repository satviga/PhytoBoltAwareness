import { Zap, Award, Twitter, Facebook, Instagram } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function PhytoHeroChallenge() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="challenge" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="challenge-section"
    >
      <div className={`text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <div className="animate-lightning mb-8">
          <Zap className="text-electric text-8xl mx-auto" size={128} />
        </div>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8 text-glow">
          The PhytoHero Challenge
        </h2>
        <p className="text-xl md:text-2xl mb-12 text-teal-bright">
          Be a PhytoHero: Every small action protects our oxygen
        </p>
        
        {/* Interactive Pledge Card */}
        <div className="bg-gradient-to-br from-teal-dark to-ocean-blue rounded-3xl p-8 shadow-2xl animate-glow max-w-2xl mx-auto border-2 border-electric">
          <div className="bg-electric rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
            <Award className="text-ocean-deep text-3xl" size={48} />
          </div>
          <h3 className="montserrat font-bold text-2xl md:text-3xl mb-6">PhytoHero Pledge</h3>
          <div className="text-lg space-y-4 mb-8">
            <p>"I pledge to protect the ocean's oxygen factories"</p>
            <p>"I will reduce my plastic footprint"</p>
            <p>"I will spread awareness about phytoplankton"</p>
            <p className="text-electric font-semibold">"I am a PhytoHero!"</p>
          </div>
          
          {/* Social Share Buttons (Non-functional) */}
          <div className="space-y-4">
            <button 
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-full transition-colors duration-300"
              data-testid="button-share-twitter"
            >
              <Twitter className="inline mr-2" size={20} /> Share on Twitter
            </button>
            <button 
              className="w-full bg-blue-800 hover:bg-blue-900 text-white font-bold py-3 px-6 rounded-full transition-colors duration-300"
              data-testid="button-share-facebook"
            >
              <Facebook className="inline mr-2" size={20} /> Share on Facebook
            </button>
            <button 
              className="w-full bg-pink-600 hover:bg-pink-700 text-white font-bold py-3 px-6 rounded-full transition-colors duration-300"
              data-testid="button-share-instagram"
            >
              <Instagram className="inline mr-2" size={20} /> Share on Instagram
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
