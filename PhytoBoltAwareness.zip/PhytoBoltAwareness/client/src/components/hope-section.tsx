import { Heart, Sprout, HandHeart, Globe } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function HopeSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="hope" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="hope-section"
    >
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1505142468610-359e7d316be0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-teal-dark bg-opacity-40"></div>
      </div>
      
      <div className={`relative z-10 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <div className="animate-float mb-6">
          <Heart className="text-electric text-8xl mx-auto animate-glow" size={128} />
        </div>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8 text-glow">
          Hope is Still Alive
        </h2>
        <div className="bg-teal-dark bg-opacity-50 rounded-2xl p-8 backdrop-blur-sm">
          <p className="text-xl md:text-3xl mb-8 leading-relaxed text-electric">
            The ocean is resilient. With awareness + action, we can reverse damage.
          </p>
          <div className="flex justify-center items-center space-x-8">
            <div className="text-center">
              <Sprout className="text-teal-bright text-4xl mb-3 animate-float mx-auto" size={64} />
              <p className="montserrat font-semibold">Recovery</p>
            </div>
            <div className="text-center">
              <HandHeart className="text-teal-bright text-4xl mb-3 animate-float mx-auto" size={64} style={{animationDelay: '0.5s'}} />
              <p className="montserrat font-semibold">Action</p>
            </div>
            <div className="text-center">
              <Globe className="text-teal-bright text-4xl mb-3 animate-float mx-auto" size={64} style={{animationDelay: '1s'}} />
              <p className="montserrat font-semibold">Revival</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
