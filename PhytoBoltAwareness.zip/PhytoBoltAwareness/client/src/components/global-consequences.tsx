import { AlertTriangle, Skull, Flame } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function GlobalConsequences() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section
      ref={ref}
      id="consequences"
      className="min-h-screen flex items-center justify-center relative"
      data-testid="consequences-section"
    >
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-red-900 bg-opacity-40"></div>
      </div>

      <div
        className={`relative z-10 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? "visible" : ""}`}
      >
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8 text-red-300">
          Global Consequences
        </h2>
        <div className="bg-black bg-opacity-50 rounded-2xl p-8 backdrop-blur-sm">
          <p className="text-xl md:text-3xl mb-8 leading-relaxed">
            If phytoplankton decline by{" "}
            <span className="text-red-400">40% (current trend)</span>,
            <span className="text-red-400"> oxygen drops 20%</span>,
            <span className="text-red-400">
              {" "}
              1 billion people lose food security
            </span>
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div className="text-center bg-red-900 bg-opacity-30 rounded-xl p-6">
              <AlertTriangle
                className="text-red-400 text-4xl mb-3 mx-auto"
                size={64}
              />
              <h3 className="montserrat font-semibold text-lg mb-2">
                Oxygen Crisis
              </h3>
              <p className="text-sm text-gray-300 mb-2">
                Breathable air becomes scarce
              </p>
              <div className="text-xs text-red-300 space-y-1">
                <p>• 20% oxygen reduction by 2100</p>
                <p>• Respiratory diseases increase 300%</p>
                <p>• High-altitude regions uninhabitable</p>
              </div>
            </div>
            <div className="text-center bg-red-900 bg-opacity-30 rounded-xl p-6">
              <Skull className="text-red-400 text-4xl mb-3 mx-auto" size={64} />
              <h3 className="montserrat font-semibold text-lg mb-2">
                Ecosystem Collapse
              </h3>
              <p className="text-sm text-gray-300 mb-2">
                Marine life extinction accelerates
              </p>
              <div className="text-xs text-red-300 space-y-1">
                <p>• 90% of fish species extinct</p>
                <p>• $2.5 trillion seafood industry lost</p>
                <p>• 820 million people undernourished</p>
              </div>
            </div>
            <div className="text-center bg-red-900 bg-opacity-30 rounded-xl p-6">
              <Flame className="text-red-400 text-4xl mb-3 mx-auto" size={64} />
              <h3 className="montserrat font-semibold text-lg mb-2">
                Climate Chaos
              </h3>
              <p className="text-sm text-gray-300 mb-2">
                Global temperature rises uncontrolled
              </p>
              <div className="text-xs text-red-300 space-y-1">
                <p>• +4°C temperature increase</p>
                <p>• Sea levels rise 2 meters</p>
                <p>• 630 million climate refugees</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
