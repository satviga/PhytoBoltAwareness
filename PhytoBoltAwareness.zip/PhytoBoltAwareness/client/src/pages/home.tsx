import HeroSection from "@/components/hero-section";
import BigQuestionSection from "@/components/big-question-section";
import PhytoplanktonHeroes from "@/components/phytoplankton-heroes";
import MicroplasticsVillain from "@/components/microplastics-villain";
import BattleComparison from "@/components/battle-comparison";
import WhyItMatters from "@/components/why-it-matters";
import GlobalConsequences from "@/components/global-consequences";
import HopeSection from "@/components/hope-section";
import ActionSteps from "@/components/action-steps";
import PhytoHeroChallenge from "@/components/phyto-hero-challenge";
import AboutSection from "@/components/about-section";
import ConclusionSection from "@/components/conclusion-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-ocean-deep text-white overflow-x-hidden">
      <HeroSection />
      <BigQuestionSection />
      <PhytoplanktonHeroes />
      <MicroplasticsVillain />
      <BattleComparison />
      <WhyItMatters />
      <GlobalConsequences />
      <HopeSection />
      <ActionSteps />
      <PhytoHeroChallenge />
      <AboutSection />
      <ConclusionSection />
      <Footer />
    </div>
  );
}
