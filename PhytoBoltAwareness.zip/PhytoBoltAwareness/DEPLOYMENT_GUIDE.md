# Free Deployment Guide for PhytoBolt Website

## Option 1: GitHub Pages (Recommended - Completely Free)

### Step 1: Create GitHub Repository
1. Go to github.com and create a new repository
2. Name it `phytobolt` or `phytobolt-website`
3. Make it public (required for free GitHub Pages)

### Step 2: Upload Your Website Files
Upload these files from your `dist/public` folder to your GitHub repository:
- `index.html`
- `assets/` folder (contains CSS and JS files)

### Step 3: Enable GitHub Pages
1. Go to your repository Settings
2. Scroll to "Pages" section
3. Select "Deploy from a branch"
4. Choose "main" branch and "/ (root)" folder
5. Click Save

### Step 4: Get Your Free URL
Your website will be available at: `https://yourusername.github.io/phytobolt`

## Option 2: Netlify (Alternative Free Option)

1. Go to netlify.com
2. Drag and drop your `dist/public` folder
3. Get instant free URL like `amazing-name-123456.netlify.app`
4. Optional: Change to custom subdomain

## Option 3: Surge.sh (Simplest Option)

1. Install surge globally: `npm install -g surge`
2. Navigate to `dist/public` folder
3. Run: `surge`
4. Choose a domain like `phytobolt-ocean.surge.sh`

## Your Website Files Location
All built files are in: `dist/public/`
- Main page: `index.html`
- Styles: `assets/index-DKJF4PWZ.css`
- Scripts: `assets/index-BFhTMdxF.js`

Your PhytoBolt environmental awareness website includes:
- Oceanic theme with smooth animations
- Statistical data about microplastics and phytoplankton
- Team information (SATVIGA & SANJAY)
- All interactive sections and floating organisms