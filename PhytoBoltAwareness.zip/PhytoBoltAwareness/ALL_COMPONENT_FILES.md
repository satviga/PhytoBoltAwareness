# All PhytoBolt Component Files

## Complete list of all 13 React component files for your PhytoBolt website:

### 1. Hero Section (hero-section.tsx)
```tsx
import { Zap, ArrowDown } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { scrollToSection } from "@/lib/utils";

export default function HeroSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      className="relative min-h-screen flex items-center justify-center hero-split"
      data-testid="hero-section"
    >
      {/* Healthy Ocean Background (Left) */}
      <div 
        className="absolute inset-0 w-1/2 left-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-teal-dark bg-opacity-30"></div>
      </div>
      
      {/* Polluted Ocean Background (Right) */}
      <div 
        className="absolute inset-0 w-1/2 right-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1621451537084-482c73073a0f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-red-900 bg-opacity-50"></div>
      </div>
      
      {/* Hero Content */}
      <div className={`relative z-20 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <div className="animate-lightning mb-6">
          <Zap className="text-electric text-8xl mx-auto" size={128} />
        </div>
        <h1 className="montserrat font-bold text-5xl md:text-7xl mb-6 text-glow">
          PhytoBolt: Zapping Microplastics to Save the Ocean's Oxygen
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-gray-200">
          The invisible crisis threatening half of Earth's oxygen
        </p>
        <button 
          onClick={() => scrollToSection('crisis')}
          className="bg-electric hover:bg-electric-dark text-ocean-deep montserrat font-bold px-8 py-4 rounded-full text-lg transition-all duration-300 animate-glow"
          data-testid="button-learn-truth"
        >
          Learn the Truth <ArrowDown className="inline ml-2" size={20} />
        </button>
      </div>

      {/* Floating Particles Animation */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-electric rounded-full animate-float"></div>
        <div className="absolute top-1/2 right-1/3 w-3 h-3 bg-teal-bright rounded-full animate-float" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-1/4 left-1/3 w-1 h-1 bg-electric rounded-full animate-float" style={{animationDelay: '2s'}}></div>
      </div>
    </section>
  );
}
```

### 2. Big Question Section (big-question-section.tsx)
```tsx
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function BigQuestionSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="big-question" 
      className="min-h-screen flex items-center justify-center relative ocean-gradient"
      data-testid="big-question-section"
    >
      <div className={`text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8 text-glow">
          Did you know?
        </h2>
        <p className="text-2xl md:text-4xl mb-12 text-teal-bright">
          Half of every breath you take comes from the ocean
        </p>
        
        {/* Animated Oxygen Bubbles */}
        <div className="relative h-40 overflow-hidden">
          <div className="absolute bottom-0 left-1/4 w-4 h-4 bg-electric rounded-full animate-bubble opacity-70"></div>
          <div className="absolute bottom-0 left-1/2 w-6 h-6 bg-teal-bright rounded-full animate-bubble opacity-80" style={{animationDelay: '0.5s'}}></div>
          <div className="absolute bottom-0 right-1/4 w-3 h-3 bg-electric rounded-full animate-bubble opacity-60" style={{animationDelay: '1s'}}></div>
          <div className="absolute bottom-0 left-1/3 w-5 h-5 bg-teal-bright rounded-full animate-bubble opacity-75" style={{animationDelay: '1.5s'}}></div>
          <div className="absolute bottom-0 right-1/3 w-2 h-2 bg-electric rounded-full animate-bubble opacity-90" style={{animationDelay: '2s'}}></div>
        </div>
      </div>
    </section>
  );
}
```

### 3. Phytoplankton Heroes (phytoplankton-heroes.tsx)
```tsx
import { Microscope, Leaf, Globe } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function PhytoplanktonHeroes() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="heroes" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="heroes-section"
    >
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1583212292454-1fe6229603b7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-ocean-deep bg-opacity-60"></div>
      </div>
      
      {/* Animated floating phytoplankton organisms */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/6 w-3 h-3 bg-teal-bright rounded-full animate-float opacity-80" style={{animationDelay: '0s'}}></div>
        <div className="absolute top-1/3 right-1/4 w-2 h-2 bg-electric rounded-full animate-float opacity-60" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-1/3 left-1/3 w-4 h-4 bg-teal-bright rounded-full animate-float opacity-70" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-2/3 right-1/3 w-2 h-2 bg-electric rounded-full animate-float opacity-80" style={{animationDelay: '3s'}}></div>
        <div className="absolute bottom-1/4 right-1/6 w-3 h-3 bg-teal-bright rounded-full animate-float opacity-50" style={{animationDelay: '4s'}}></div>
        <div className="absolute top-1/2 left-1/5 w-1 h-1 bg-electric rounded-full animate-float opacity-90" style={{animationDelay: '2.5s'}}></div>
      </div>
      
      <div className={`relative z-10 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8">
          Meet the Heroes: <span className="text-teal-bright text-glow">Phytoplankton</span>
        </h2>
        <p className="text-2xl md:text-3xl mb-4 text-electric">
          Tiny ocean plants = Earth's oxygen factories
        </p>
        <div className="bg-teal-dark bg-opacity-30 rounded-xl p-4 mb-8">
          <p className="text-sm text-electric font-semibold">Amazing Fact: 1 trillion phytoplankton can fit in a single glass of seawater!</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          <div className="bg-teal-dark bg-opacity-50 rounded-xl p-6 animate-glow">
            <Microscope className="text-electric text-4xl mb-4 mx-auto" size={64} />
            <h3 className="montserrat font-semibold text-xl mb-2">Microscopic Size</h3>
            <p className="text-sm mb-3">Invisible to the naked eye but vital to all life</p>
            <div className="text-xs text-gray-400 space-y-1">
              <p>• 0.2-2 micrometers in size</p>
              <p>• 5 billion in 1 liter of water</p>
              <p>• Smaller than bacteria</p>
            </div>
          </div>
          <div className="bg-teal-dark bg-opacity-50 rounded-xl p-6 animate-glow" style={{animationDelay: '0.3s'}}>
            <Leaf className="text-electric text-4xl mb-4 mx-auto" size={64} />
            <h3 className="montserrat font-semibold text-xl mb-2">Oxygen Producers</h3>
            <p className="text-sm mb-3">Generate 50-85% of the oxygen we breathe</p>
            <div className="text-xs text-gray-400 space-y-1">
              <p>• 330 billion tons O₂ yearly</p>
              <p>• More than all forests combined</p>
              <p>• Via photosynthesis process</p>
            </div>
          </div>
          <div className="bg-teal-dark bg-opacity-50 rounded-xl p-6 animate-glow" style={{animationDelay: '0.6s'}}>
            <Globe className="text-electric text-4xl mb-4 mx-auto" size={64} />
            <h3 className="montserrat font-semibold text-xl mb-2">Global Impact</h3>
            <p className="text-sm mb-3">Foundation of marine food chains worldwide</p>
            <div className="text-xs text-gray-400 space-y-1">
              <p>• Feed 99% of marine life</p>
              <p>• $2.5 trillion ocean economy</p>
              <p>• Support 3 billion people</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
```

### 4. Microplastics Villain (microplastics-villain.tsx)
```tsx
import { Sun, Skull, AlertTriangle } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function MicroplasticsVillain() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="villain" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="villain-section"
    >
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1605600659908-0ef719419d41?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-red-900 bg-opacity-60"></div>
      </div>
      
      <div className={`relative z-10 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8">
          Enter the Villain: <span className="text-red-400">Microplastics</span>
        </h2>
        <p className="text-xl md:text-2xl mb-8 text-gray-200">
          Invisible plastic particles block sunlight, poison phytoplankton, and spread everywhere
        </p>
        <div className="bg-red-900 bg-opacity-30 rounded-xl p-4 mb-8 border border-red-500">
          <p className="text-sm text-red-300 font-semibold">Shocking Reality: 51 trillion microplastic pieces contaminate our oceans - 500x more than stars in our galaxy!</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="bg-red-900 bg-opacity-50 rounded-xl p-6 border border-red-500">
            <Sun className="text-red-400 text-4xl mb-4 mx-auto" size={64} />
            <h3 className="montserrat font-semibold text-xl mb-4">Blocks Sunlight</h3>
            <p className="mb-3">Prevents photosynthesis in phytoplankton</p>
            <div className="text-xs text-red-300 space-y-1">
              <p>• 30% light reduction in contaminated areas</p>
              <p>• Photosynthesis drops by 50%</p>
              <p>• Creates ocean "dead zones"</p>
            </div>
          </div>
          <div className="bg-red-900 bg-opacity-50 rounded-xl p-6 border border-red-500">
            <Skull className="text-red-400 text-4xl mb-4 mx-auto" size={64} />
            <h3 className="montserrat font-semibold text-xl mb-4">Toxic Poison</h3>
            <p className="mb-3">Releases harmful chemicals into ocean cells</p>
            <div className="text-xs text-red-300 space-y-1">
              <p>• 232 toxic chemicals in microplastics</p>
              <p>• Endocrine disruptors damage reproduction</p>
              <p>• Heavy metals accumulate in organisms</p>
            </div>
          </div>
        </div>

        {/* Microplastic Size Comparison */}
        <div className="bg-red-900 bg-opacity-30 rounded-xl p-6 border border-red-500">
          <div className="flex items-center justify-center space-x-8">
            <div className="text-center">
              <div className="w-1 h-1 bg-red-400 rounded-full mx-auto mb-2"></div>
              <p className="text-xs text-gray-300">0.1mm microplastic</p>
            </div>
            <div className="text-center">
              <div className="w-2 h-2 bg-red-400 rounded-full mx-auto mb-2"></div>
              <p className="text-xs text-gray-300">1mm plastic fragment</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-red-400">5mm size</p>
              <p className="text-gray-300">microplastics ingested by plankton</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
```

### 5. Battle Comparison (battle-comparison.tsx)
```tsx
import { Heart, Skull } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function BattleComparison() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="battle" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="battle-section"
    >
      <div className={`w-full max-w-7xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl text-center mb-12 text-glow">
          The Silent Battle
        </h2>
        <p className="text-xl md:text-2xl text-center mb-12 text-teal-bright">
          Phytoplankton vs. microplastics: A war we can't see, but we must fight
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Healthy Phytoplankton Side */}
          <div className="relative rounded-2xl overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1583212292454-1fe6229603b7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Healthy glowing phytoplankton" 
              className="w-full h-80 object-cover"
            />
            <div className="absolute inset-0 bg-teal-dark bg-opacity-30 flex items-center justify-center">
              <div className="text-center">
                <Heart className="text-electric text-6xl mb-4 animate-glow mx-auto" size={96} />
                <h3 className="montserrat font-bold text-2xl text-glow">Healthy Heroes</h3>
                <p className="text-lg mt-2">Thriving & producing oxygen</p>
              </div>
            </div>
          </div>
          
          {/* Polluted Side */}
          <div className="relative rounded-2xl overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1621451537084-482c73073a0f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Microplastics contaminating ocean water" 
              className="w-full h-80 object-cover"
            />
            <div className="absolute inset-0 bg-red-900 bg-opacity-60 flex items-center justify-center">
              <div className="text-center">
                <Skull className="text-red-400 text-6xl mb-4 mx-auto" size={96} />
                <h3 className="montserrat font-bold text-2xl text-red-400">Microplastic-Choked Waters</h3>
                <p className="text-lg mt-2">Phytoplankton suffocating and dying</p>
                <div className="text-xs text-red-300 mt-3 space-y-1">
                  <p>• 51 trillion microplastic pieces in oceans</p>
                  <p>• 40% phytoplankton population decline</p>
                  <p>• 8 million tons new plastic yearly</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
```

### 6. Why It Matters (why-it-matters.tsx)
```tsx
import { Heart, Fish, Thermometer } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function WhyItMatters() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="crisis" 
      className="min-h-screen flex items-center justify-center relative ocean-gradient"
      data-testid="crisis-section"
    >
      <div className={`text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-12 text-glow">
          Why It Matters to Us
        </h2>
        
        <div className="space-y-8">
          <div className="flex items-center justify-start bg-teal-dark bg-opacity-30 rounded-xl p-6 animate-glow">
            <div className="bg-electric rounded-full p-4 mr-6 flex-shrink-0">
              <Heart className="text-ocean-deep text-2xl" size={32} />
            </div>
            <div className="text-left">
              <h3 className="montserrat font-semibold text-xl mb-2">50-85% of Earth's oxygen</h3>
              <p className="text-gray-300">comes from phytoplankton in our oceans</p>
              <p className="text-sm text-electric mt-1">That's more oxygen than all forests combined!</p>
            </div>
          </div>
          
          <div className="flex items-center justify-start bg-teal-dark bg-opacity-30 rounded-xl p-6 animate-glow" style={{animationDelay: '0.3s'}}>
            <div className="bg-electric rounded-full p-4 mr-6 flex-shrink-0">
              <Fish className="text-ocean-deep text-2xl" size={32} />
            </div>
            <div className="text-left">
              <h3 className="montserrat font-semibold text-xl mb-2">99% of marine food chains</h3>
              <p className="text-gray-300">depend entirely on these microscopic organisms</p>
              <p className="text-sm text-electric mt-1">3 billion people rely on ocean food sources</p>
            </div>
          </div>
          
          <div className="flex items-center justify-start bg-teal-dark bg-opacity-30 rounded-xl p-6 animate-glow" style={{animationDelay: '0.6s'}}>
            <div className="bg-electric rounded-full p-4 mr-6 flex-shrink-0">
              <Thermometer className="text-ocean-deep text-2xl" size={32} />
            </div>
            <div className="text-left">
              <h3 className="montserrat font-semibold text-xl mb-2">40 billion tons of CO2</h3>
              <p className="text-gray-300">absorbed annually by ocean phytoplankton</p>
              <p className="text-sm text-electric mt-1">Equal to removing 8.5 billion cars from roads</p>
            </div>
          </div>
        </div>
        
        {/* Animated Earth Visual */}
        <div className="mt-12 relative">
          <img 
            src="https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400" 
            alt="Earth from space showing blue planet" 
            className="w-60 h-60 rounded-full mx-auto animate-glow object-cover"
          />
        </div>
      </div>
    </section>
  );
}
```

### 7. Global Consequences (global-consequences.tsx)
```tsx
import { AlertTriangle, Skull, TrendingDown } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function GlobalConsequences() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="consequences" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="consequences-section"
    >
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-red-900 bg-opacity-40"></div>
      </div>
      
      <div className={`relative z-10 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8 text-red-300">
          Global Consequences
        </h2>
        <div className="bg-black bg-opacity-50 rounded-2xl p-8 backdrop-blur-sm">
          <p className="text-xl md:text-3xl mb-8 leading-relaxed">
            If phytoplankton decline by <span className="text-red-400">40% (current trend)</span>, 
            <span className="text-red-400"> oxygen drops 20%</span>, 
            <span className="text-red-400"> 1 billion people lose food security</span>
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div className="text-center bg-red-900 bg-opacity-30 rounded-xl p-6">
              <AlertTriangle className="text-red-400 text-4xl mb-3 mx-auto" size={64} />
              <h3 className="montserrat font-semibold text-lg mb-2">Oxygen Crisis</h3>
              <p className="text-sm text-gray-300 mb-2">Breathable air becomes scarce</p>
              <div className="text-xs text-red-300 space-y-1">
                <p>• 20% oxygen reduction by 2100</p>
                <p>• Respiratory diseases increase 300%</p>
                <p>• High-altitude regions uninhabitable</p>
              </div>
            </div>
            <div className="text-center bg-red-900 bg-opacity-30 rounded-xl p-6">
              <Skull className="text-red-400 text-4xl mb-3 mx-auto" size={64} />
              <h3 className="montserrat font-semibold text-lg mb-2">Ecosystem Collapse</h3>
              <p className="text-sm text-gray-300 mb-2">Marine life extinction accelerates</p>
              <div className="text-xs text-red-300 space-y-1">
                <p>• 90% of fish species extinct</p>
                <p>• $2.5 trillion seafood industry lost</p>
                <p>• Coral reefs completely die</p>
              </div>
            </div>
            <div className="text-center bg-red-900 bg-opacity-30 rounded-xl p-6">
              <TrendingDown className="text-red-400 text-4xl mb-3 mx-auto" size={64} />
              <h3 className="montserrat font-semibold text-lg mb-2">Economic Devastation</h3>
              <p className="text-sm text-gray-300 mb-2">Global food systems collapse</p>
              <div className="text-xs text-red-300 space-y-1">
                <p>• 1 billion people face starvation</p>
                <p>• Mass climate refugee migrations</p>
                <p>• $24 trillion economic losses</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
```

### 8. Hope Section (hope-section.tsx)
```tsx
import { Heart, Sprout, HandHeart, Globe } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function HopeSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="hope" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="hope-section"
    >
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1505142468610-359e7d316be0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-teal-dark bg-opacity-40"></div>
      </div>
      
      <div className={`relative z-10 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <div className="animate-float mb-6">
          <Heart className="text-electric text-8xl mx-auto animate-glow" size={128} />
        </div>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8 text-glow">
          Hope is Still Alive
        </h2>
        <div className="bg-teal-dark bg-opacity-50 rounded-2xl p-8 backdrop-blur-sm">
          <p className="text-xl md:text-3xl mb-8 leading-relaxed text-electric">
            The ocean is resilient. With awareness + action, we can reverse damage.
          </p>
          <div className="flex justify-center items-center space-x-8">
            <div className="text-center">
              <Sprout className="text-teal-bright text-4xl mb-3 animate-float mx-auto" size={64} />
              <p className="montserrat font-semibold">Recovery</p>
            </div>
            <div className="text-center">
              <HandHeart className="text-teal-bright text-4xl mb-3 animate-float mx-auto" size={64} style={{animationDelay: '0.5s'}} />
              <p className="montserrat font-semibold">Action</p>
            </div>
            <div className="text-center">
              <Globe className="text-teal-bright text-4xl mb-3 animate-float mx-auto" size={64} style={{animationDelay: '1s'}} />
              <p className="montserrat font-semibold">Revival</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
```

### 9. Action Steps (action-steps.tsx)
```tsx
import { Ban, Hand, Users } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function ActionSteps() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="action-steps" 
      className="min-h-screen flex items-center justify-center relative ocean-gradient"
      data-testid="action-steps-section"
    >
      <div className={`text-center max-w-5xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-12 text-glow">
          What Can We Do?
        </h2>
        <p className="text-xl md:text-2xl mb-12 text-teal-bright">
          Simple steps matter
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-teal-dark bg-opacity-40 rounded-2xl p-8 hover:bg-opacity-60 transition-all duration-300 animate-glow">
            <Ban className="text-electric text-5xl mb-6 mx-auto" size={80} />
            <h3 className="montserrat font-bold text-2xl mb-4">Reduce Plastics</h3>
            <p className="text-lg mb-4">Say NO to single-use plastics</p>
            <div className="bg-ocean-blue bg-opacity-30 rounded-xl p-4 mb-4">
              <p className="text-sm text-electric font-semibold">Impact: 8 million tons of plastic enter oceans yearly</p>
            </div>
            <ul className="text-sm text-gray-300 space-y-3">
              <li>• <span className="text-electric">Reusable bags:</span> Save 1000+ plastic bags/year</li>
              <li>• <span className="text-electric">Metal straws:</span> Prevent 36,500 plastic straws annually</li>
              <li>• <span className="text-electric">Glass containers:</span> Reduce microplastic contamination</li>
              <li>• <span className="text-electric">Refill stations:</span> Avoid 1,500 plastic bottles/year</li>
              <li>• <span className="text-electric">Bamboo products:</span> Biodegradable alternatives</li>
            </ul>
          </div>
          
          <div className="bg-teal-dark bg-opacity-40 rounded-2xl p-8 hover:bg-opacity-60 transition-all duration-300 animate-glow" style={{animationDelay: '0.3s'}}>
            <Hand className="text-electric text-5xl mb-6 mx-auto" size={80} />
            <h3 className="montserrat font-bold text-2xl mb-4">Support Cleanups</h3>
            <p className="text-lg mb-4">Join ocean restoration efforts</p>
            <div className="bg-ocean-blue bg-opacity-30 rounded-xl p-4 mb-4">
              <p className="text-sm text-electric font-semibold">Success: 4.4M volunteers removed 350M lbs of trash</p>
            </div>
            <ul className="text-sm text-gray-300 space-y-3">
              <li>• <span className="text-electric">Beach cleanups:</span> Remove 2,000 lbs plastic/event</li>
              <li>• <span className="text-electric">River cleanup:</span> Prevent 80% ocean-bound plastic</li>
              <li>• <span className="text-electric">Sponsor programs:</span> $1 = 1 lb removed</li>
              <li>• <span className="text-electric">Volunteer time:</span> 2 hours = 50 lbs collected</li>
              <li>• <span className="text-electric">Adopt coastlines:</span> Long-term protection zones</li>
            </ul>
          </div>
          
          <div className="bg-teal-dark bg-opacity-40 rounded-2xl p-8 hover:bg-opacity-60 transition-all duration-300 animate-glow" style={{animationDelay: '0.6s'}}>
            <Users className="text-electric text-5xl mb-6 mx-auto" size={80} />
            <h3 className="montserrat font-bold text-2xl mb-4">Spread Awareness</h3>
            <p className="text-lg mb-4">Educate others about the crisis</p>
            <div className="bg-ocean-blue bg-opacity-30 rounded-xl p-4 mb-4">
              <p className="text-sm text-electric font-semibold">Power: 1 person influences 150 others on average</p>
            </div>
            <ul className="text-sm text-gray-300 space-y-3">
              <li>• <span className="text-electric">Social sharing:</span> Reach 500+ people per post</li>
              <li>• <span className="text-electric">School talks:</span> Educate 30 students/session</li>
              <li>• <span className="text-electric">Family discussions:</span> Change household habits</li>
              <li>• <span className="text-electric">Workplace initiatives:</span> Reduce office plastic 60%</li>
              <li>• <span className="text-electric">Community events:</span> Multiply local impact</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
```

### 10. Phyto Hero Challenge (phyto-hero-challenge.tsx)
```tsx
import { Zap, Award, Twitter, Facebook, Instagram } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function PhytoHeroChallenge() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="challenge" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="challenge-section"
    >
      <div className={`text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <div className="animate-lightning mb-8">
          <Zap className="text-electric text-8xl mx-auto" size={128} />
        </div>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8 text-glow">
          The PhytoHero Challenge
        </h2>
        <p className="text-xl md:text-2xl mb-12 text-teal-bright">
          Be a PhytoHero: Every small action protects our oxygen
        </p>
        
        {/* Interactive Pledge Card */}
        <div className="bg-gradient-to-br from-teal-dark to-ocean-blue rounded-3xl p-8 shadow-2xl animate-glow max-w-2xl mx-auto border-2 border-electric">
          <div className="bg-electric rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
            <Award className="text-ocean-deep text-3xl" size={48} />
          </div>
          <h3 className="montserrat font-bold text-2xl md:text-3xl mb-6">PhytoHero Pledge</h3>
          <div className="text-lg space-y-4 mb-8">
            <p>"I pledge to protect the ocean's oxygen factories"</p>
            <p>"I will reduce my plastic footprint"</p>
            <p>"I will spread awareness about phytoplankton"</p>
            <p className="text-electric font-semibold">"I am a PhytoHero!"</p>
          </div>
          
          {/* Social Share Buttons (Non-functional) */}
          <div className="space-y-4">
            <button 
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-full transition-colors duration-300"
              data-testid="button-share-twitter"
            >
              <Twitter className="inline mr-2" size={20} /> Share on Twitter
            </button>
            <button 
              className="w-full bg-blue-800 hover:bg-blue-900 text-white font-bold py-3 px-6 rounded-full transition-colors duration-300"
              data-testid="button-share-facebook"
            >
              <Facebook className="inline mr-2" size={20} /> Share on Facebook
            </button>
            <button 
              className="w-full bg-pink-600 hover:bg-pink-700 text-white font-bold py-3 px-6 rounded-full transition-colors duration-300"
              data-testid="button-share-instagram"
            >
              <Instagram className="inline mr-2" size={20} /> Share on Instagram
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
```

### 11. About Section (about-section.tsx)
```tsx
import { User, GraduationCap, Trophy } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function AboutSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="about" 
      className="min-h-screen flex items-center justify-center relative ocean-gradient"
      data-testid="about-section"
    >
      <div className={`text-center max-w-5xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <h2 className="montserrat font-bold text-4xl md:text-6xl mb-8 text-glow">
          The Team Behind PhytoBolt
        </h2>
        <p className="text-xl md:text-2xl mb-12 text-teal-bright">
          We built PhytoBolt to turn awareness into action
        </p>
        
        <div className="bg-teal-dark bg-opacity-40 rounded-3xl p-8 mb-12 backdrop-blur-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8 max-w-2xl mx-auto">
            {/* Team Member Cards */}
            <div className="bg-ocean-blue bg-opacity-50 rounded-xl p-6">
              <div className="w-16 h-16 bg-electric rounded-full mx-auto mb-4 flex items-center justify-center">
                <User className="text-ocean-deep text-2xl" size={32} />
              </div>
              <h3 className="montserrat font-semibold text-lg">SATVIGA</h3>
              <p className="text-sm text-gray-300">UX Designer & Research Lead</p>
            </div>
            
            <div className="bg-ocean-blue bg-opacity-50 rounded-xl p-6">
              <div className="w-16 h-16 bg-electric rounded-full mx-auto mb-4 flex items-center justify-center">
                <User className="text-ocean-deep text-2xl" size={32} />
              </div>
              <h3 className="montserrat font-semibold text-lg">SANJAY</h3>
              <p className="text-sm text-gray-300">Lead Developer</p>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-lg mb-4">
              <GraduationCap className="inline text-electric mr-2" size={24} />
              Ocean University - Computer Science & Environmental Studies
            </p>
            <p className="text-lg mb-6">
              <Trophy className="inline text-electric mr-2" size={24} />
              HackTheOcean 2025 Participants
            </p>
            <blockquote className="text-xl md:text-2xl italic text-electric border-l-4 border-electric pl-6 max-w-3xl mx-auto">
              "We built PhytoBolt to turn awareness into action—because the ocean can't wait."
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}
```

### 12. Conclusion Section (conclusion-section.tsx)
```tsx
import { Zap, Microscope, Heart } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { scrollToSection } from "@/lib/utils";

export default function ConclusionSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      ref={ref}
      id="conclusion" 
      className="min-h-screen flex items-center justify-center relative"
      data-testid="conclusion-section"
    >
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-ocean-deep bg-opacity-60"></div>
      </div>
      
      <div className={`relative z-10 text-center max-w-4xl mx-auto px-6 section-slide ${isVisible ? 'visible' : ''}`}>
        <div className="animate-lightning mb-8">
          <Zap className="text-electric text-8xl mx-auto" size={128} />
        </div>
        
        <blockquote className="text-3xl md:text-5xl montserrat font-bold mb-12 leading-tight">
          <span className="text-glow">"The ocean gives us life</span>
          <br />
          <span className="text-electric">now it's our turn to protect it."</span>
        </blockquote>
        
        <div className="flex items-center justify-center space-x-4 mb-12">
          <div className="animate-glow">
            <img 
              src="https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200" 
              alt="Earth glowing blue from space" 
              className="w-32 h-32 rounded-full object-cover"
            />
          </div>
          <div className="text-electric text-6xl animate-lightning">
            <Zap size={96} />
          </div>
          <div className="text-center">
            <h3 className="montserrat font-bold text-2xl text-electric">PhytoBolt</h3>
            <p className="text-sm text-gray-300">Saving Oxygen Factories</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button 
            onClick={() => scrollToSection('heroes')}
            className="bg-teal-dark bg-opacity-50 hover:bg-opacity-70 rounded-xl p-6 transition-all duration-300 animate-glow"
            data-testid="button-learn-more"
          >
            <Microscope className="text-electric text-3xl mb-3 mx-auto" size={48} />
            <h4 className="montserrat font-semibold">Learn More</h4>
          </button>
          
          <button 
            onClick={() => scrollToSection('challenge')}
            className="bg-teal-dark bg-opacity-50 hover:bg-opacity-70 rounded-xl p-6 transition-all duration-300 animate-glow"
            data-testid="button-take-pledge"
          >
            <Heart className="text-electric text-3xl mb-3 mx-auto" size={48} />
            <h4 className="montserrat font-semibold">Take Action</h4>
          </button>
        </div>
      </div>
    </section>
  );
}
```

### 13. Footer (footer.tsx)
```tsx
import { Zap, Mail, Twitter, Hash } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-ocean-deep py-12 border-t border-teal-dark" data-testid="footer">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <div className="mb-8">
          <div className="flex items-center justify-center mb-4">
            <Zap className="text-electric text-4xl mr-3 animate-lightning" size={64} />
            <h3 className="montserrat font-bold text-2xl">PhytoBolt</h3>
          </div>
          <p className="text-gray-400 mb-6">Saving the Ocean's Oxygen Factories</p>
          
          <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-8">
            <a 
              href="mailto:team@phytobolt.org" 
              className="text-teal-bright hover:text-electric transition-colors duration-300"
              data-testid="link-email"
            >
              <Mail className="inline mr-2" size={20} />team@phytobolt.org
            </a>
            <div className="text-teal-bright">
              <Twitter className="inline mr-2" size={20} />#SavePhytoplankton
            </div>
            <div className="text-teal-bright">
              <Hash className="inline mr-2" size={20} />HackTheOcean2025
            </div>
          </div>
        </div>
        
        <div className="border-t border-teal-dark pt-6">
          <p className="text-gray-500 text-sm">
            © 2025 PhytoBolt. All rights reserved. Built with 💚 for the ocean.
          </p>
        </div>
      </div>
    </footer>
  );
}
```

## Additional Helper Files

### Custom Hook (hooks/use-scroll-animation.tsx)
```tsx
import { useEffect, useRef, useState } from 'react';

export function useScrollAnimation(threshold = 0.1) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, [threshold]);

  return { ref, isVisible };
}
```

### Utilities (lib/utils.ts)
```tsx
import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function scrollToSection(sectionId: string) {
  const element = document.getElementById(sectionId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
}
```

## Complete Package
This gives you all 13 component files plus helpers that make up your complete PhytoBolt environmental awareness website. Each component is fully functional with:
- Oceanic theming and animations
- Statistical data and environmental facts
- Team information (SATVIGA & SANJAY)
- Smooth scroll animations
- Responsive design
- Ready for free hosting deployment