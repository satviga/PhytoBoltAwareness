# PhytoBolt Complete Website Code

## Overview
Your PhytoBolt environmental awareness website - a modern, interactive single-page application about microplastics threatening phytoplankton.

## Key Features
- Oceanic theme with deep blues, teals, and electric yellow
- Smooth scroll animations and floating organisms
- Comprehensive statistical data about environmental crisis
- Team information: SATVIGA (UX Designer) & SANJAY (Developer)
- 12 interactive sections with storytelling flow

## Main Files Structure

### 1. Main Application (client/src/App.tsx)
```tsx
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
```

### 2. Home Page (client/src/pages/home.tsx)
```tsx
import HeroSection from "@/components/hero-section";
import BigQuestionSection from "@/components/big-question-section";
import PhytoplanktonHeroes from "@/components/phytoplankton-heroes";
import MicroplasticsVillain from "@/components/microplastics-villain";
import BattleComparison from "@/components/battle-comparison";
import WhyItMatters from "@/components/why-it-matters";
import GlobalConsequences from "@/components/global-consequences";
import HopeSection from "@/components/hope-section";
import ActionSteps from "@/components/action-steps";
import PhytoHeroChallenge from "@/components/phyto-hero-challenge";
import AboutSection from "@/components/about-section";
import ConclusionSection from "@/components/conclusion-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-ocean-deep text-white overflow-x-hidden">
      <HeroSection />
      <BigQuestionSection />
      <PhytoplanktonHeroes />
      <MicroplasticsVillain />
      <BattleComparison />
      <WhyItMatters />
      <GlobalConsequences />
      <HopeSection />
      <ActionSteps />
      <PhytoHeroChallenge />
      <AboutSection />
      <ConclusionSection />
      <Footer />
    </div>
  );
}
```

### 3. Main HTML (client/index.html)
```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1" />
    <title>PhytoBolt: Saving the Ocean's Oxygen Factories</title>
    <meta name="description" content="Learn about the invisible crisis of microplastics threatening phytoplankton - the ocean's oxygen factories. Discover how these tiny marine organisms produce 50% of Earth's oxygen and what we can do to protect them.">
    
    <!-- Open Graph tags for social sharing -->
    <meta property="og:title" content="PhytoBolt: Saving the Ocean's Oxygen Factories">
    <meta property="og:description" content="The invisible crisis threatening half of Earth's oxygen. Learn about phytoplankton vs microplastics.">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=630">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800&family=Poppins:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

### 4. Styling (client/src/index.css)
```css
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800&family=Poppins:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap');

@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  /* PhytoBolt specific colors */
  --ocean-deep: hsl(220 70% 8%);
  --ocean-blue: hsl(225 74% 30%);
  --teal-bright: hsl(172 85% 38%);
  --teal-dark: hsl(172 67% 30%);
  --electric: hsl(54 92% 62%);
  --electric-dark: hsl(45 93% 47%);
}

@layer base {
  body {
    @apply font-sans antialiased bg-ocean-deep text-white overflow-x-hidden;
    font-family: 'Poppins', sans-serif;
  }

  .montserrat {
    font-family: 'Montserrat', sans-serif;
  }
}

@layer utilities {
  .section-slide {
    opacity: 0;
    transform: translateY(50px);
    transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
  }
  
  .section-slide.visible {
    opacity: 1;
    transform: translateY(0);
  }
  
  .ocean-gradient {
    background: linear-gradient(135deg, var(--ocean-deep) 0%, var(--ocean-blue) 50%, var(--teal-dark) 100%);
  }
  
  .text-glow {
    text-shadow: 0 0 20px rgba(20, 184, 166, 0.8);
  }

  @keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-20px); }
  }
  
  @keyframes glow {
    0% { box-shadow: 0 0 20px rgba(20, 184, 166, 0.5); }
    100% { box-shadow: 0 0 40px rgba(20, 184, 166, 0.8); }
  }
  
  @keyframes bubble {
    0% { transform: translateY(100px) scale(0); }
    50% { transform: translateY(-50px) scale(1); }
    100% { transform: translateY(-200px) scale(0); }
  }
  
  @keyframes lightning {
    0%, 100% { opacity: 0.7; }
    50% { opacity: 1; filter: brightness(1.5); }
  }

  .animate-float { animation: float 6s ease-in-out infinite; }
  .animate-glow { animation: glow 2s ease-in-out infinite alternate; }
  .animate-bubble { animation: bubble 4s ease-in-out infinite; }
  .animate-lightning { animation: lightning 3s ease-in-out infinite; }
}
```

## Component Files
All component files are in `client/src/components/` including:
- `hero-section.tsx` - Split-screen hero with healthy vs polluted ocean
- `phytoplankton-heroes.tsx` - Educational section about ocean's oxygen factories
- `microplastics-villain.tsx` - The threat of microplastics explained
- `battle-comparison.tsx` - Visual comparison of healthy vs contaminated waters
- `global-consequences.tsx` - Impact statistics and future predictions
- `action-steps.tsx` - Plastic reduction strategies with impact data
- `about-section.tsx` - Team information (SATVIGA & SANJAY)
- `footer.tsx` - Contact and social information

## Key Technologies
- React 18 with TypeScript
- Tailwind CSS for styling
- Wouter for routing
- Lucide React for icons
- Custom animations and smooth scrolling
- Responsive design for all devices

## Environmental Data Included
- 51 trillion microplastic pieces in oceans
- 8 million tons of plastic enter oceans yearly
- 40% phytoplankton decline trend
- 50% of Earth's oxygen from phytoplankton
- Statistical impact of plastic reduction strategies

## Deployment Ready
Built files are in `dist/public/` folder:
- `index.html` - Main page
- `assets/` - CSS and JavaScript bundles
- Ready for free hosting on Netlify, GitHub Pages, or Surge.sh

Your website showcases the environmental crisis with engaging visuals, comprehensive data, and clear calls to action while maintaining a professional oceanic theme throughout.